var _0x3effd6 = _0x454f;
function spoofTimer() {
  var e = _0x3effd6,
    t = { wDgSU: e(492), kvPxV: e(493) },
    n = document[e(498) + e(482)](t[e(489)]);
  n && (n[e(507)] = t[e(476)]);
}
function saveTabSwitchEvent() {}
function saveFullScreenExitEvent() {}
function saveCopyPasteAttemptEvent() {}
function _0x454f(e, t) {
  var n = _0x3145();
  return (_0x454f = function (e, t) {
    return n[(e -= 461)];
  })(e, t);
}
function _0x3145() {
  var e = [
    "atePropaga",
    "stopImmedi",
    "222648gfGAlB",
    "kvPxV",
    "205212ZSHPVK",
    "steAttempt",
    "saveFullSc",
    "matchMedia",
    "ctrlKey",
    "ById",
    "6018enNsmm",
    "/labs/",
    "jgtLh",
    "rbyDU",
    "RuHVJ",
    "XhbNC",
    "wDgSU",
    "/exercises",
    "2268FbpPOE",
    "timer",
    "40:00",
    "includes",
    "saveTabSwi",
    "apply",
    "5337090NyKkRh",
    "getElement",
    "Event",
    "stener",
    "15ZiueKy",
    "addEventLi",
    "bYelr",
    "/candidate",
    "81930zoEJbd",
    "ent",
    "innerHTML",
    "13008DamCFT",
    "tchEvent",
    "keydown",
    "326024wQyItY",
    "QeNnk",
    "which",
    "1323MlGHem",
    "11fNgqlG",
    "visibility",
    "tion",
    "reenExitEv",
    "prototype",
    "change",
    "open",
    "saveCopyPa",
  ];
  return (_0x3145 = function () {
    return e;
  })();
}
(function (e, t) {
  for (var n = _0x454f, f = _0x3145(); ; )
    try {
      if (
        268552 ===
        -parseInt(n(461)) / 1 +
          parseInt(n(477)) / 2 +
          (parseInt(n(501)) / 3) * (-parseInt(n(475)) / 4) +
          parseInt(n(505)) / 5 +
          (parseInt(n(483)) / 6) * (-parseInt(n(464)) / 7) +
          (parseInt(n(508)) / 8) * (parseInt(n(491)) / 9) +
          (parseInt(n(497)) / 10) * (parseInt(n(465)) / 11)
      )
        break;
      f.push(f.shift());
    } catch (e) {
      f.push(f.shift());
    }
})(),
  (window[_0x3effd6(480)] =
    window[_0x3effd6(480)] ||
    function () {
      return { addEventListener: function () {}, removeEventListener: function () {}, matches: !1 };
    }),
  document[_0x3effd6(502) + _0x3effd6(500)](
    _0x3effd6(466) + _0x3effd6(470),
    function (e) {
      var t = _0x3effd6;
      e[t(474) + t(473) + t(467)]();
    },
    !0
  ),
  document[_0x3effd6(502) + _0x3effd6(500)](
    _0x3effd6(510),
    function (e) {
      var t = _0x3effd6,
        n = {
          XhbNC: function (e, t) {
            return e == t;
          },
          rbyDU: function (e, t) {
            return e == t;
          },
        };
      e[t(481)] &&
        (n[t(488)](e[t(463)], "67") || n[t(488)](e[t(463)], "86") || n[t(486)](e[t(463)], "88")) &&
        e[t(474) + t(473) + t(467)]();
    },
    !0
  ),
  (function () {
    var e = _0x3effd6,
      t = { bYelr: e(504) + e(490) + "/", RuHVJ: e(504) + e(484) },
      n = XMLHttpRequest[e(469)][e(471)];
    XMLHttpRequest[e(469)][e(471)] = function (f, r, i, a, s) {
      var o = e;
      r[o(494)](t[o(503)]) || r[o(494)](t[o(487)]) || n[o(496)](this, arguments);
    };
  })(),
  setInterval(spoofTimer, 1e3),
  (window[_0x3effd6(495) + _0x3effd6(509)] = saveTabSwitchEvent),
  (window[_0x3effd6(479) + _0x3effd6(468) + _0x3effd6(506)] = saveFullScreenExitEvent),
  (window[_0x3effd6(472) + _0x3effd6(478) + _0x3effd6(499)] = saveCopyPasteAttemptEvent),
  (function () {
    var e = _0x3effd6,
      t = { QeNnk: e(504) + e(490) + "/", jgtLh: e(504) + e(484) },
      n = XMLHttpRequest[e(469)][e(471)];
    XMLHttpRequest[e(469)][e(471)] = function (f, r, i, a, s) {
      var o = e;
      r[o(494)](t[o(462)]) || r[o(494)](t[o(485)]) || n[o(496)](this, arguments);
    };
  })();
