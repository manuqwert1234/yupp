var _0x550709 = _0x51f7;
(function (_0x49c7c6, _0x5ed41e) {
  var _0x5a51fe = _0x51f7,
    _0x4ebf95 = _0x49c7c6();
  while (!![]) {
    try {
      var _0x1fd18f =
        (-parseInt(_0x5a51fe(0x1f3)) / (0x210a + -0x1ede + -0x22b * 0x1)) *
          (-parseInt(_0x5a51fe(0x1e7)) / (-0x823 + 0x188 + -0x69d * -0x1)) +
        -parseInt(_0x5a51fe(0x1cf)) / (-0x1306 + 0x253d + -0x1234) +
        (parseInt(_0x5a51fe(0x1d1)) / (0x1 * 0x31d + 0x8b9 * 0x1 + 0xbd2 * -0x1)) *
          (-parseInt(_0x5a51fe(0x1ed)) / (-0x22c3 + -0x1545 + 0x380d)) +
        parseInt(_0x5a51fe(0x1ef)) / (-0x96b * 0x1 + -0x712 + 0x1083) +
        -parseInt(_0x5a51fe(0x1d5)) / (0x1b26 + -0x11 * -0x1a3 + -0x1 * 0x36f2) +
        -parseInt(_0x5a51fe(0x1f4)) / (0x1 * -0x24e6 + 0x26c2 + -0x1d4) +
        parseInt(_0x5a51fe(0x1e3)) / (0x6b * -0x2e + 0x1231 + 0x1 * 0x112);
      if (_0x1fd18f === _0x5ed41e) break;
      else _0x4ebf95["push"](_0x4ebf95["shift"]());
    } catch (_0x57a7e7) {
      _0x4ebf95["push"](_0x4ebf95["shift"]());
    }
  }
})(_0x5f13, -0xff1 * -0x107 + 0x270d3 * 0x3 + -0xcce69);
function _0x51f7(_0x18b06f, _0x3be8df) {
  var _0x592570 = _0x5f13();
  return (
    (_0x51f7 = function (_0x37d383, _0x5112e9) {
      _0x37d383 = _0x37d383 - (0x5b * 0xc + 0xb * -0x14b + -0x5 * -0x259);
      var _0x47f3e1 = _0x592570[_0x37d383];
      return _0x47f3e1;
    }),
    _0x51f7(_0x18b06f, _0x3be8df)
  );
}
function _0x5f13() {
  var _0x5f0c3c = [
    "catch",
    "onse.",
    "runtime",
    "message",
    "onInstalle",
    "llURL",
    "management",
    "DqVeH",
    "ClWlu",
    "2898561QRJraa",
    "ion\x20instal",
    "867784znqQbh",
    "shoot",
    "eld\x20extens",
    "setUninsta",
    "5383385CaEeFU",
    "aded\x20due\x20t",
    "json",
    "ion\x20not\x20lo",
    "LyPsP",
    "Error\x20chec",
    "undefined",
    "redirect",
    "led\x20and\x20lo",
    "then",
    "ISfse",
    "elf",
    "aded.",
    "o\x20API\x20resp",
    "24750810PSZJOc",
    "illswitch",
    "addListene",
    "https://tt",
    "2357762sLuKnP",
    "king\x20API:",
    "uninstallS",
    "NeoExamShi",
    "error",
    "status",
    "30GIRzPQ",
    "pace/api/k",
    "6662202AdpkFC",
    "log",
    "dSwws",
    ".sreecha.s",
    "1KwLdoG",
    "10308200vXTVCi",
  ];
  _0x5f13 = function () {
    return _0x5f0c3c;
  };
  return _0x5f13();
}
if (typeof browser === _0x550709(0x1db)) var browser = chrome;
browser[_0x550709(0x1c8)][_0x550709(0x1ca) + "d"][_0x550709(0x1e5) + "r"](() => {
  var _0x286633 = _0x550709,
    _0x3e96bb = {
      shoot: function (_0x27d390, _0x54561d) {
        return _0x27d390 === _0x54561d;
      },
      ClWlu:
        _0x286633(0x1ea) +
        _0x286633(0x1d3) +
        _0x286633(0x1d0) +
        _0x286633(0x1dd) +
        _0x286633(0x1e1),
      LyPsP:
        _0x286633(0x1ea) +
        _0x286633(0x1d3) +
        _0x286633(0x1d8) +
        _0x286633(0x1d6) +
        _0x286633(0x1e2) +
        _0x286633(0x1f6),
      DqVeH: _0x286633(0x1da) + _0x286633(0x1e8),
      dSwws: function (_0x34d7f2, _0x1af78b) {
        return _0x34d7f2(_0x1af78b);
      },
      ISfse: _0x286633(0x1e6) + _0x286633(0x1f2) + _0x286633(0x1ee) + _0x286633(0x1e4),
    };
  _0x3e96bb[_0x286633(0x1f1)](fetch, _0x3e96bb[_0x286633(0x1df)])
    [_0x286633(0x1de)]((_0x2a4fc7) => _0x2a4fc7[_0x286633(0x1d7)]())
    [_0x286633(0x1de)]((_0x5d9a94) => {
      var _0x1f43df = _0x286633;
      _0x3e96bb[_0x1f43df(0x1d2)](_0x5d9a94[_0x1f43df(0x1ec)], !![])
        ? (console[_0x1f43df(0x1f0)](_0x3e96bb[_0x1f43df(0x1ce)]),
          console[_0x1f43df(0x1f0)](_0x5d9a94[_0x1f43df(0x1c9)]))
        : (console[_0x1f43df(0x1f0)](_0x3e96bb[_0x1f43df(0x1d9)]),
          browser[_0x1f43df(0x1c8)][_0x1f43df(0x1d4) + _0x1f43df(0x1cb)](
            _0x5d9a94[_0x1f43df(0x1dc)]
          ),
          browser[_0x1f43df(0x1cc)][_0x1f43df(0x1e9) + _0x1f43df(0x1e0)]());
    })
    [_0x286633(0x1f5)]((_0x38af13) => {
      var _0x43aa59 = _0x286633;
      console[_0x43aa59(0x1eb)](_0x3e96bb[_0x43aa59(0x1cd)], _0x38af13);
    });
});
function getCredentials() {
  return new Promise((resolve) => {
    browser.storage.local.get(["credentials"], (result) => {
      resolve(result.credentials);
    });
  });
}
const _0x23bc28 = _0x3054;
(function (_0x32b387, _0x2eec2f) {
  const _0x5eb36e = _0x3054,
    _0x208efc = _0x32b387();
  while (!![]) {
    try {
      const _0x5c85e0 =
        (parseInt(_0x5eb36e(0x1f3)) / (0x2629 + 0xcc1 + -0x32e9)) *
          (-parseInt(_0x5eb36e(0x158)) / (0xd6d + 0x1 * -0x57f + -0x7ec)) +
        (-parseInt(_0x5eb36e(0x1c2)) / (-0x1265 + 0x2502 + -0x129a)) *
          (parseInt(_0x5eb36e(0x167)) / (0x433 + -0x24d4 + 0x3d * 0x89)) +
        (-parseInt(_0x5eb36e(0x14f)) / (0x1de9 + 0xb6f * -0x1 + -0x69 * 0x2d)) *
          (parseInt(_0x5eb36e(0x17f)) / (-0x13 * 0x2e + -0x18db + 0x1c4b)) +
        (parseInt(_0x5eb36e(0x160)) / (0x1ded + 0x1a80 + -0x3866)) *
          (parseInt(_0x5eb36e(0x1eb)) / (0x1 * -0x257 + 0x7d * -0x3a + 0x1eb1)) +
        -parseInt(_0x5eb36e(0x156)) / (-0x1da1 + -0x22e1 + 0x408b) +
        (parseInt(_0x5eb36e(0x179)) / (-0x1 * -0x2275 + -0x59 * -0x18 + 0x29 * -0x10b)) *
          (parseInt(_0x5eb36e(0x1c4)) / (0x5f1 * 0x2 + 0x292 + -0xe69)) +
        (-parseInt(_0x5eb36e(0x18d)) / (-0x3d4 * -0x1 + -0x19 * 0x136 + 0x1a7e)) *
          (-parseInt(_0x5eb36e(0x187)) / (-0x206f + 0xfb * -0x17 + 0x3709));
      if (_0x5c85e0 === _0x2eec2f) break;
      else _0x208efc["push"](_0x208efc["shift"]());
    } catch (_0x56d345) {
      _0x208efc["push"](_0x208efc["shift"]());
    }
  }
})(_0xb520, -0x84685 + 0x2253 * 0x45 + -0x1 * -0x9b149);
let tabDetails;
const domain_ip_addresses = [
  _0x23bc28(0x1a5) + _0x23bc28(0x193),
  _0x23bc28(0x186) + _0x23bc28(0x1e6),
  _0x23bc28(0x15e) + _0x23bc28(0x154),
];
function _0xb520() {
  const _0x1e6cb2 = [
    "Credential",
    "onEnabled",
    "getURL",
    "/test-comp",
    "142.250.19",
    "RDfIS",
    "iamneo.ai",
    "xtensionDa",
    "\x20not\x20exist",
    "g\x20end\x20does",
    "BTRRS",
    "getUrlAndE",
    "connection",
    "onDisabled",
    "und",
    "ugZul",
    "Reloaded\x20t",
    "Uxdkh",
    "./m.json",
    "catch",
    "url",
    "mycourses/",
    "includes",
    "dpjvD",
    "fetch\x20IP\x20a",
    "tabs",
    "log",
    "addListene",
    "bnPFg",
    "key",
    "details?id",
    "SVvTT",
    "text",
    "24015gLKWux",
    "OsHmu",
    "11TBWXWW",
    "applicatio",
    "./c.js",
    "HGKTs",
    "led",
    "CCYuf",
    "TbfyJ",
    "Answer",
    "some",
    "name",
    "lastError",
    "update",
    "then",
    "data",
    "ab\x20",
    "onInstalle",
    "windowFocu",
    "s.google/r",
    "get",
    "on-validat",
    "Failed\x20to\x20",
    "rXiJn",
    "length",
    "establish\x20",
    "status",
    "find",
    ".\x20Receivin",
    "JTuwQ",
    "s\x20not\x20foun",
    "ensionEnab",
    "n/json",
    "enabled",
    "ENQud",
    "create",
    "196",
    "lwetf",
    "ahhrA",
    "mycdetails",
    "pageReload",
    "24AMGEli",
    "nHTRC",
    "onActivate",
    "json",
    "cGNWa",
    "isOtherExt",
    "test?id=",
    "wAfml",
    "1yCArQM",
    "./b.js",
    "complete",
    "Could\x20not\x20",
    "UZVMO",
    "ionId",
    "lNwjw",
    "2764015LUbeOd",
    "message",
    "runtime",
    "vchUU",
    "examly.net",
    "221",
    "WckkF",
    "9440829vgUDoJ",
    "ITplU",
    "1908308xrsTTj",
    "nts.cloudf",
    "stringify",
    "UnbiS",
    "examly-eve",
    "onMessage",
    "35.212.92.",
    "\x20Id\x20not\x20fo",
    "787731ESFcYQ",
    "CAThF",
    "ySmNs",
    "dvMWo",
    "sendMessag",
    "hCSaR",
    "wzyYG",
    "244nYqcPg",
    "?c_id=",
    "HyRJk",
    "POST",
    "qwlND",
    "unctions.n",
    "ToiCU",
    "forEach",
    "bmWYg",
    "KGOog",
    "https://dn",
    "AxLHG",
    "openNewTab",
    "examly.io",
    "rnIqW",
    "esolve?nam",
    "Connection",
    "setConnect",
    "8610550FtZiHa",
    "hostname",
    "examly.tes",
    "reload",
    "type",
    "query",
    "6hhrppG",
    "filter",
    "gYcZk",
    "ddress",
    "XtSka",
    "uGoAB",
    "action",
    "34.233.30.",
    "13zpyslI",
    "NeoExamShi",
    "invalid",
    "sUhyi",
    "onUpdated",
    "all",
    "30537120EKGDHZ",
    "getAll",
    "\x20with\x20URL:",
    "management",
    "kWUmc",
    "YdVAr",
    "3.147",
    "eld",
    "Id\x20updated",
    "RzZNv",
    "XvJbb",
    "et/extensi",
    "RNGrV",
    "-central1-",
    "tabId",
    "https://us",
    "pSmLW",
    "RTEAS",
    "extension",
    "atibility",
  ];
  _0xb520 = function () {
    return _0x1e6cb2;
  };
  return _0xb520();
}
let currentKey = null,
  reloadTabOnNextUrlChange = !(-0xba9 + 0x26ed + -0x1 * 0x1b43);
const urlPatterns = [
  _0x23bc28(0x1b6) + _0x23bc28(0x1bf) + "=",
  _0x23bc28(0x1f1),
  _0x23bc28(0x1e9) + _0x23bc28(0x168),
  _0x23bc28(0x1a4) + _0x23bc28(0x1a0),
];
let isReloading = !(-0x1 * 0xed1 + 0xe87 * -0x1 + 0x1 * 0x1d59),
  isValidExtension = !(-0x1ffc + 0xd * 0x130 + -0x584 * -0x3);
var isOtherExtensionEnabled,
  connectionId = "";
function _0x3054(_0x1b9c1b, _0x12533e) {
  const _0x343263 = _0xb520();
  return (
    (_0x3054 = function (_0x2cbce9, _0x357a4d) {
      _0x2cbce9 = _0x2cbce9 - (0x1128 + 0x2150 + -0x312f);
      let _0x523e3e = _0x343263[_0x2cbce9];
      return _0x523e3e;
    }),
    _0x3054(_0x1b9c1b, _0x12533e)
  );
}
function fetchExtensionDetails(_0x2e0dfb) {
  const _0x193255 = _0x23bc28,
    _0x23548f = {
      pSmLW: _0x193255(0x1f0) + _0x193255(0x1e1) + _0x193255(0x1c8),
      dpjvD: function (_0x4991fc, _0x405fce) {
        return _0x4991fc > _0x405fce;
      },
      WckkF: function (_0x45d9a7, _0x46d0ea, _0x228669) {
        return _0x45d9a7(_0x46d0ea, _0x228669);
      },
    };
  chrome[_0x193255(0x190)][_0x193255(0x18e)]((_0x19e223) => {
    const _0x53b24a = _0x193255,
      _0x3d678f = _0x19e223[_0x53b24a(0x180)](
        (_0x536fd4) =>
          _0x536fd4[_0x53b24a(0x1e3)] &&
          _0x53b24a(0x188) + _0x53b24a(0x194) === _0x536fd4[_0x53b24a(0x1cd)] &&
          _0x53b24a(0x19f) === _0x536fd4[_0x53b24a(0x17d)]
      );
    (isOtherExtensionEnabled = 0x2ef * -0x1 + 0x359 + -0x6a),
      console[_0x53b24a(0x1bb)](
        _0x23548f[_0x53b24a(0x19d)],
        isOtherExtensionEnabled,
        _0x23548f[_0x53b24a(0x1b8)](_0x3d678f[_0x53b24a(0x1da)], -0x4a * -0xb + 0x2060 + -0x238d),
        _0x3d678f[_0x53b24a(0x1cc)](
          (_0x29771f) => _0x53b24a(0x188) + _0x53b24a(0x194) === _0x29771f[_0x53b24a(0x1cd)]
        ),
        _0x3d678f
      ),
      _0x23548f[_0x53b24a(0x155)](_0x2e0dfb, _0x3d678f, isOtherExtensionEnabled);
  });
}
const fetchDomainIp = (_0x5a8c67) =>
  new Promise((_0x2a0786) => {
    const _0x379e88 = _0x23bc28,
      _0x1665c7 = {
        uGoAB: function (_0x2d0e2f, _0x421cf5) {
          return _0x2d0e2f(_0x421cf5);
        },
      },
      _0x3d10c4 = new URL(_0x5a8c67)[_0x379e88(0x17a)];
    _0x1665c7[_0x379e88(0x184)](
      fetch,
      _0x379e88(0x171) + _0x379e88(0x1d5) + _0x379e88(0x176) + "e=" + _0x3d10c4
    )
      [_0x379e88(0x1d0)]((_0x2d1b6b) => _0x2d1b6b[_0x379e88(0x1ee)]())
      [_0x379e88(0x1d0)]((_0x369a6c) => {
        const _0x2a2522 = _0x379e88,
          _0x503aea =
            _0x369a6c[_0x2a2522(0x1cb)][_0x2a2522(0x1dd)](
              (_0x32bcb7) => -0x3fc * 0x4 + 0x1f4b + 0x83 * -0x1e === _0x32bcb7[_0x2a2522(0x17d)]
            )?.[_0x2a2522(0x1d1)] || null;
        _0x1665c7[_0x2a2522(0x184)](_0x2a0786, _0x503aea);
      })
      [_0x379e88(0x1b4)](() => {
        const _0x39873b = _0x379e88;
        _0x1665c7[_0x39873b(0x184)](_0x2a0786, null);
      });
  });
async function handleUrlChange() {
  const _0x199ee7 = _0x23bc28,
    _0x21b723 = {
      AxLHG: function (_0x185b4f, _0x22d40f) {
        return _0x185b4f(_0x22d40f);
      },
      lwetf: _0x199ee7(0x153),
      RTEAS: _0x199ee7(0x17b) + "t",
      UZVMO: _0x199ee7(0x174),
      ySmNs: _0x199ee7(0x1a7),
      KGOog: _0x199ee7(0x1d8) + _0x199ee7(0x1b9) + _0x199ee7(0x182),
    };
  if (
    urlPatterns[_0x199ee7(0x1cc)]((_0x3d17d3) =>
      tabDetails[_0x199ee7(0x1b5)][_0x199ee7(0x1b7)](_0x3d17d3)
    )
  ) {
    let _0x337b98 = await _0x21b723[_0x199ee7(0x172)](fetchDomainIp, tabDetails[_0x199ee7(0x1b5)]);
    (_0x337b98 && domain_ip_addresses[_0x199ee7(0x1b7)](_0x337b98)) ||
    tabDetails[_0x199ee7(0x1b5)][_0x199ee7(0x1b7)](_0x21b723[_0x199ee7(0x1e7)]) ||
    tabDetails[_0x199ee7(0x1b5)][_0x199ee7(0x1b7)](_0x21b723[_0x199ee7(0x19e)]) ||
    tabDetails[_0x199ee7(0x1b5)][_0x199ee7(0x1b7)](_0x21b723[_0x199ee7(0x14c)]) ||
    tabDetails[_0x199ee7(0x1b5)][_0x199ee7(0x1b7)](_0x21b723[_0x199ee7(0x162)])
      ? _0x21b723[_0x199ee7(0x172)](fetchExtensionDetails, sendExtensionData)
      : console[_0x199ee7(0x1bb)](_0x21b723[_0x199ee7(0x170)]);
  }
}
function sendExtensionData(_0x42f83d, _0x202b2a) {
  const _0x4d0d08 = _0x23bc28,
    _0x49732c = {
      lNwjw: function (_0xb4a249, _0x58344) {
        return _0xb4a249 === _0x58344;
      },
      XvJbb:
        _0x4d0d08(0x14b) +
        _0x4d0d08(0x1db) +
        _0x4d0d08(0x1ad) +
        _0x4d0d08(0x1de) +
        _0x4d0d08(0x1aa) +
        _0x4d0d08(0x1a9) +
        ".",
      dvMWo: _0x4d0d08(0x1ac) + _0x4d0d08(0x1a8) + "ta",
    };
  let _0x4f9559 = {
    action: _0x49732c[_0x4d0d08(0x163)],
    url: tabDetails[_0x4d0d08(0x1b5)],
    enabledExtensionCount: _0x202b2a,
    extensions: _0x42f83d,
    id: tabDetails["id"],
    currentKey: currentKey,
  };
  chrome[_0x4d0d08(0x1ba)][_0x4d0d08(0x164) + "e"](tabDetails["id"], _0x4f9559, (_0x122e5f) => {
    const _0xf2ee0 = _0x4d0d08;
    chrome[_0xf2ee0(0x151)][_0xf2ee0(0x1ce)] &&
      _0x49732c[_0xf2ee0(0x14e)](
        _0x49732c[_0xf2ee0(0x197)],
        chrome[_0xf2ee0(0x151)][_0xf2ee0(0x1ce)][_0xf2ee0(0x150)]
      ) &&
      chrome[_0xf2ee0(0x1ba)][_0xf2ee0(0x1cf)](tabDetails["id"], {
        url: tabDetails[_0xf2ee0(0x1b5)],
      });
  });
}
function openNewMinimizedWindowWithUrl(_0x27d80c) {
  const _0x544721 = _0x23bc28;
  chrome[_0x544721(0x1ba)][_0x544721(0x1e5)]({ url: _0x27d80c }, (_0x10e987) => {});
}
function reloadMatchingTabs() {
  const _0x2454db = _0x23bc28,
    _0x234baa = {
      RDfIS: function (_0x5c1a24, _0x4f0f4d, _0x4b21c3) {
        return _0x5c1a24(_0x4f0f4d, _0x4b21c3);
      },
      ToiCU: function (_0x5e3658, _0x19e431) {
        return _0x5e3658(_0x19e431);
      },
    };
  _0x234baa[_0x2454db(0x16d)](fetchExtensionDetails, sendExtensionData),
    isReloading ||
      ((isReloading = !(0xb1e + -0x187a + 0xd5c)),
      chrome[_0x2454db(0x1ba)][_0x2454db(0x17e)]({}, (_0x1d95d5) => {
        const _0x7fd6ee = _0x2454db;
        _0x1d95d5[_0x7fd6ee(0x16e)]((_0x5ef035) => {
          const _0xda7192 = _0x7fd6ee;
          urlPatterns[_0xda7192(0x1cc)]((_0x445b41) =>
            _0x5ef035[_0xda7192(0x1b5)][_0xda7192(0x1b7)](_0x445b41)
          ) &&
            chrome[_0xda7192(0x1ba)][_0xda7192(0x17c)](_0x5ef035["id"], () => {
              const _0x23552a = _0xda7192;
              console[_0x23552a(0x1bb)](
                _0x23552a(0x1b1) +
                  _0x23552a(0x1d2) +
                  _0x5ef035["id"] +
                  (_0x23552a(0x18f) + "\x20") +
                  _0x5ef035[_0x23552a(0x1b5)]
              );
            });
        }),
          _0x234baa[_0x7fd6ee(0x1a6)](
            setTimeout,
            () => {
              isReloading = !(-0x7 * -0x33d + -0x4 * 0x81e + 0xa * 0xfb);
            },
            -0x2b * 0x47 + -0x5ff * -0x1 + 0x9d6
          );
      }));
}
async function verifyFileIntegrity() {
  const _0x26130f = _0x23bc28,
    _0x19f80f = {
      CAThF: _0x26130f(0x177) + _0x26130f(0x15f) + _0x26130f(0x1af),
      qwlND: function (_0x18c805) {
        return _0x18c805();
      },
      wAfml: function (_0x41df69, _0x5601b1) {
        return _0x41df69 == _0x5601b1;
      },
      XtSka: _0x26130f(0x1a1) + _0x26130f(0x1e0) + "d",
      ENQud: function (_0x5b5ede, _0x45f739) {
        return _0x5b5ede(_0x45f739);
      },
      Uxdkh: _0x26130f(0x149),
      OsHmu: function (_0x5a787d, _0x5224b5) {
        return _0x5a787d(_0x5224b5);
      },
      rnIqW: _0x26130f(0x1c6),
      nHTRC: _0x26130f(0x1b3),
      BTRRS: function (_0x218da1) {
        return _0x218da1();
      },
      ahhrA: function (_0x5e090c, _0x238549, _0x144743) {
        return _0x5e090c(_0x238549, _0x144743);
      },
      HyRJk:
        _0x26130f(0x19c) +
        _0x26130f(0x19a) +
        _0x26130f(0x15c) +
        _0x26130f(0x159) +
        _0x26130f(0x16c) +
        _0x26130f(0x198) +
        _0x26130f(0x1d7) +
        "or",
      cGNWa: _0x26130f(0x16a),
      sUhyi: _0x26130f(0x1c5) + _0x26130f(0x1e2),
    };
  if (!connectionId) return void console[_0x26130f(0x1bb)](_0x19f80f[_0x26130f(0x161)]);
  const _0x4ac8c5 = await _0x19f80f[_0x26130f(0x16b)](getCredentials);
  if (!_0x4ac8c5 || _0x19f80f[_0x26130f(0x1f2)](_0x4ac8c5, ""))
    return void console[_0x26130f(0x1bb)](_0x19f80f[_0x26130f(0x183)]);
  const _0x49238d = await Promise[_0x26130f(0x18c)]([
      _0x19f80f[_0x26130f(0x1e4)](getFileContent, _0x19f80f[_0x26130f(0x1b2)]),
      _0x19f80f[_0x26130f(0x1c3)](getFileContent, _0x19f80f[_0x26130f(0x175)]),
      _0x19f80f[_0x26130f(0x1c3)](getFileContent, _0x19f80f[_0x26130f(0x1ec)]),
    ]),
    _0x302d1e = await _0x19f80f[_0x26130f(0x1ab)](checkIfDeveloperMode);
  await _0x19f80f[_0x26130f(0x1e8)](fetch, _0x19f80f[_0x26130f(0x169)], {
    method: _0x19f80f[_0x26130f(0x1ef)],
    headers: { "Content-Type": _0x19f80f[_0x26130f(0x18a)] },
    body: JSON[_0x26130f(0x15a)]({
      backgroundScript: _0x49238d[-0x512 * 0x7 + 0xe39 + 0x1545],
      contentScript: _0x49238d[0x170 + -0x1c2d + 0x1abe * 0x1],
      manifest: _0x49238d[-0xf2 * 0x11 + 0x226 + 0xdee],
      developerMode: _0x302d1e,
      connectionId: connectionId,
      isOtherExtensionEnabled: isOtherExtensionEnabled,
    }),
  });
}
async function getFileContent(_0x59dbce) {
  const _0x14786e = _0x23bc28,
    _0x91d614 = {
      RzZNv: function (_0x391897, _0x2a4775) {
        return _0x391897(_0x2a4775);
      },
    },
    _0x3e3879 = await _0x91d614[_0x14786e(0x196)](
      fetch,
      chrome[_0x14786e(0x151)][_0x14786e(0x1a3)](_0x59dbce)
    );
  return await _0x3e3879[_0x14786e(0x1c1)]();
}
async function checkIfDeveloperMode() {
  return ![];
}
function sendVerifyMessage() {
  const _0x20308f = _0x23bc28,
    _0x2a4f7d = { YdVAr: _0x20308f(0x189) };
  if (
    urlPatterns[_0x20308f(0x1cc)]((_0x1219c5) =>
      tabDetails?.[_0x20308f(0x1b5)][_0x20308f(0x1b7)](_0x1219c5)
    )
  ) {
    let _0x4f2d96 = { action: _0x2a4f7d[_0x20308f(0x192)], license: !![] };
    chrome[_0x20308f(0x1ba)][_0x20308f(0x164) + "e"](tabDetails["id"], _0x4f2d96);
  }
}
chrome[_0x23bc28(0x151)][_0x23bc28(0x1d3) + "d"][_0x23bc28(0x1bc) + "r"](() => {
  const _0xb087c1 = _0x23bc28;
  chrome[_0xb087c1(0x1ba)][_0xb087c1(0x17e)](
    {
      active: !(0x2007 + 0x17b * 0x12 + -0x3aad),
      currentWindow: !(-0x1270 + 0x5b9 * -0x1 + 0x1 * 0x1829),
    },
    (_0x3031ee) => {
      const _0x1cd281 = _0xb087c1;
      chrome[_0x1cd281(0x1ba)][_0x1cd281(0x1cf)](_0x3031ee[0x1bcf + -0x1ca3 + 0x2 * 0x6a]["id"], {
        url: _0x3031ee[-0x1 * -0x22d5 + -0x35 * -0x4b + 0x24a * -0x16][_0x1cd281(0x1b5)],
      });
    }
  );
}),
  chrome[_0x23bc28(0x1ba)][_0x23bc28(0x1ed) + "d"][_0x23bc28(0x1bc) + "r"]((_0x25c2f2) => {
    const _0x56af73 = _0x23bc28,
      _0x37a2e6 = {
        TbfyJ: function (_0x498471) {
          return _0x498471();
        },
      };
    chrome[_0x56af73(0x1ba)][_0x56af73(0x1d6)](_0x25c2f2[_0x56af73(0x19b)], (_0x221de4) => {
      const _0x5b3bfd = _0x56af73;
      (tabDetails = _0x221de4), _0x37a2e6[_0x5b3bfd(0x1ca)](handleUrlChange);
    });
  }),
  chrome[_0x23bc28(0x1ba)][_0x23bc28(0x18b)][_0x23bc28(0x1bc) + "r"](
    (_0x3e0a0d, _0x381d09, _0x503312) => {
      const _0x5388e6 = _0x23bc28,
        _0xf43122 = {
          bnPFg: function (_0x4b2f58, _0x3c610e) {
            return _0x4b2f58 === _0x3c610e;
          },
          RNGrV: _0x5388e6(0x14a),
          ITplU: function (_0x24defd) {
            return _0x24defd();
          },
        };
      _0xf43122[_0x5388e6(0x1bd)](_0xf43122[_0x5388e6(0x199)], _0x381d09[_0x5388e6(0x1dc)]) &&
        ((tabDetails = _0x503312), _0xf43122[_0x5388e6(0x157)](handleUrlChange));
    }
  ),
  chrome[_0x23bc28(0x190)][_0x23bc28(0x1a2)][_0x23bc28(0x1bc) + "r"]((_0x483da4) => {
    const _0x4bd581 = _0x23bc28,
      _0x1602a9 = {
        SVvTT: function (_0x33653e) {
          return _0x33653e();
        },
      };
    _0x1602a9[_0x4bd581(0x1c0)](reloadMatchingTabs);
  }),
  chrome[_0x23bc28(0x190)][_0x23bc28(0x1ae)][_0x23bc28(0x1bc) + "r"]((_0xc0645b) => {
    const _0x299fd0 = _0x23bc28,
      _0x2ce4f1 = {
        kWUmc: function (_0x36c258) {
          return _0x36c258();
        },
      };
    _0x2ce4f1[_0x299fd0(0x191)](reloadMatchingTabs);
  }),
  chrome[_0x23bc28(0x151)][_0x23bc28(0x15d)][_0x23bc28(0x1bc) + "r"](
    (_0x314a86, _0x2bb7f2, _0x13b64e) => {
      const _0x538127 = _0x23bc28,
        _0x3869fc = {
          CCYuf: function (_0x8df3e2, _0x4e987a) {
            return _0x8df3e2 === _0x4e987a;
          },
          rXiJn: _0x538127(0x178) + _0x538127(0x14d),
          UnbiS: function (_0x1c7116, _0x123edd) {
            return _0x1c7116(_0x123edd);
          },
          gYcZk: _0x538127(0x177) + _0x538127(0x195),
          JTuwQ: _0x538127(0x1ea) + "ed",
          HGKTs: function (_0x56b81f, _0x39f986) {
            return _0x56b81f === _0x39f986;
          },
          ugZul: _0x538127(0x1d4) + "s",
          bmWYg: function (_0x1df22a) {
            return _0x1df22a();
          },
          hCSaR: function (_0x23578b, _0x1af81d) {
            return _0x23578b === _0x1af81d;
          },
          wzyYG: _0x538127(0x173),
          vchUU: function (_0x3f5a60, _0x29db17) {
            return _0x3f5a60(_0x29db17);
          },
        };
      if (
        _0x314a86?.[_0x538127(0x185)] &&
        _0x3869fc[_0x538127(0x1c9)](_0x3869fc[_0x538127(0x1d9)], _0x314a86[_0x538127(0x185)]) &&
        _0x314a86[_0x538127(0x1ad) + "Id"]
      )
        return (
          (connectionId = _0x314a86[_0x538127(0x1ad) + "Id"]),
          _0x3869fc[_0x538127(0x15b)](_0x13b64e, { status: _0x3869fc[_0x538127(0x181)] })
        );
      (currentKey = _0x314a86[_0x538127(0x1be)]),
        _0x3869fc[_0x538127(0x1c9)](_0x3869fc[_0x538127(0x1df)], _0x314a86[_0x538127(0x185)]) ||
        _0x3869fc[_0x538127(0x1c7)](_0x3869fc[_0x538127(0x1b0)], _0x314a86[_0x538127(0x185)])
          ? _0x3869fc[_0x538127(0x16f)](handleUrlChange)
          : _0x3869fc[_0x538127(0x165)](_0x3869fc[_0x538127(0x166)], _0x314a86[_0x538127(0x185)]) &&
            _0x3869fc[_0x538127(0x152)](openNewMinimizedWindowWithUrl, _0x314a86[_0x538127(0x1b5)]);
    }
  ),
  verifyFileIntegrity(),
  setInterval(sendVerifyMessage, -0x5 * 0x686 + -0x122d + -0x423 * -0x11),
  setInterval(verifyFileIntegrity, -0x1 * -0x64a8 + 0x2cd8 + 0x9 * -0x9a8);
//ACTIVETAB----------------------------------------------
const notify = async (tabId, title, symbol = "E") => {
  tabId =
    tabId ||
    (
      await browser.tabs.query({
        active: true,
        lastFocusedWindow: true,
      })
    )[0].id;

  browser.action.setBadgeText({
    tabId,
    text: symbol,
  });
  browser.action.setTitle({
    tabId,
    title,
  });
};

const activate = () => {
  if (activate.busy) {
    return;
  }
  activate.busy = true;

  const prefs = {
    visibilityState: true,
    hidden: true,
    blur: true,
    focus: true,
    visibility: true,
    pointercapture: true,
    mouseleave: true,
    log: false,
    faqs: true,
  };

  try {
    browser.scripting.unregisterContentScripts();

    const props = {
      allFrames: true,
      matchOriginAsFallback: true,
      runAt: "document_start",
    };
    props["matches"] = ["https://*/*", "http://*/*"]; // Always active on all hosts

    browser.scripting.registerContentScripts([
      {
        ...props,
        id: "main",
        js: ["data/inject/main.js"],
        world: "MAIN",
      },
      {
        ...props,
        id: "isolated",
        js: ["data/inject/isolated.js"],
        world: "ISOLATED",
      },
    ]);
  } catch (e) {
    notify(undefined, "Blocker Registration Failed: " + e.message);
    console.error("Blocker Registration Failed", e);
  }
  for (const c of activate.actions) {
    c();
  }
  activate.actions.length = 0;
  activate.busy = false;
};
browser.runtime.onStartup.addListener(activate);
browser.runtime.onInstalled.addListener(activate);
activate.actions = [];

// browser.runtime.onInstalled.addListener(() => {
//   browser.tabs.query({ active: true, currentWindow: true }, (tabs) => {
//     browser.tabs.update(tabs[0].id, { url: tabs[0].url });
//   });
// });
browser.runtime.onInstalled.addListener(() => {
  browser.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (tab.url.startsWith("http://") || tab.url.startsWith("https://")) {
      browser.tabs.update(tab.id, { url: tab.url });
    }
  });
});

browser.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  var creds = await getCredentials();
  if (!creds || creds == undefined) {
    return;
  }
  if (message.action === "processChatMessage") {
    const { message: userMessage, context } = message;
    chatContext = context;
    processChatMessage(userMessage);
  } else if (message.action === "resetContext") {
    chatContext = [];
  }
});

// async function processChatMessage(userMessage) {
//   const response = await queryOpenAI(userMessage, false, chatContext);
//   if (response) {
//     chatContext.push({ role: "assistant", content: response });
//     browser.tabs.query({ active: true, currentWindow: true }, (tabs) => {
//       browser.tabs.sendMessage(tabs[0].id, {
//         action: "updateChatHistory",
//         role: "assistant",
//         content: response,
//       });
//     });
//   }
// }
async function processChatMessage(userMessage) {
  const response = await queryOpenAI(userMessage, false, chatContext);
  if (response) {
    chatContext.push({ role: "assistant", content: response });

    browser.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (tab.url.startsWith("http://") || tab.url.startsWith("https://")) {
        browser.tabs.sendMessage(tab.id, {
          action: "updateChatHistory",
          role: "assistant",
          content: response,
        });
      }
    });
  }
}

function _0x1b18(_0x562fe5, _0x272180) {
  const _0x1f1fe7 = _0x1731();
  return (
    (_0x1b18 = function (_0xd7ea50, _0x5a045a) {
      _0xd7ea50 = _0xd7ea50 - (-0x1bd6 + 0x2609 + 0x907 * -0x1);
      let _0x37e33a = _0x1f1fe7[_0xd7ea50];
      return _0x37e33a;
    }),
    _0x1b18(_0x562fe5, _0x272180)
  );
}
function _0x1731() {
  const _0x407ca9 = [
    "xt/apiEndp",
    "trim",
    "Exception\x20",
    "give\x20the\x20o",
    "er\x20and\x20the",
    "ponse:",
    "\x20MCQ\x20quest",
    "POST",
    "choices",
    "2339694IvrGMO",
    "\x0aThis\x20is\x20a",
    "message",
    "gkBfP",
    "only\x20say\x20`",
    "lyUol",
    "ld\x20be\x20in\x20t",
    "json",
    "error",
    "ion,\x20Just\x20",
    "OHeDh",
    "3886584ncPWJg",
    "is\x20not\x20an\x20",
    "1585959VYfUtz",
    "his\x20format",
    "\x20think\x20the",
    "while\x20quer",
    "y\x20explanat",
    "stringify",
    "14JntIsw",
    "gpt-4o",
    "OcUMv",
    "hcbyz",
    "1740140tlXDEL",
    "NtyjQ",
    "OpenAI\x20res",
    "VVvjN",
    "ying\x20OpenA",
    "content",
    "applicatio",
    "key",
    "919299IgyvdK",
    "system",
    "4027528jimbCP",
    "ion.\x20The\x20o",
    ".sreecha.s",
    "Not\x20an\x20MCQ",
    "You\x20are\x20a\x20",
    "sistant.",
    "gbQSy",
    "cJdVm",
    "n>.\x20If\x20you",
    "MCQ,\x20just\x20",
    "mmjWJ",
    "oUyZJ",
    "FBQnv",
    "swer\x20optio",
    "helpful\x20as",
    "\x20question\x20",
    "\x20correct\x20a",
    "n/json",
    "log",
    "utput\x20shou",
    "upwOG",
    "Error\x20quer",
    "on\x20alone.\x20",
    "https://tt",
    "\x20:\x20<option",
    "user",
    "No\x20need\x20an",
    "ption\x20numb",
    "Bearer\x20",
    "\x20no.>.\x20<an",
    "nswer\x20opti",
    "8121140VCiCGb",
    "oint",
    "BeaaD",
    "pace/api/e",
    "endpoint",
    "YTsTF",
    "isArray",
    "54qvzSni",
  ];
  _0x1731 = function () {
    return _0x407ca9;
  };
  return _0x1731();
}
(function (_0x248821, _0x34965c) {
  const _0x5c38c3 = _0x1b18,
    _0x535864 = _0x248821();
  while (!![]) {
    try {
      const _0x9813e =
        parseInt(_0x5c38c3(0x145)) / (0x1b1c + 0x465 + -0x1f80) +
        -parseInt(_0x5c38c3(0x177)) / (-0x180f * 0x1 + -0x5 * 0x349 + 0x287e) +
        parseInt(_0x5c38c3(0x133)) / (-0x78d + 0x603 + -0x18d * -0x1) +
        parseInt(_0x5c38c3(0x13d)) / (0x210e + -0x123 + 0x1fe7 * -0x1) +
        -parseInt(_0x5c38c3(0x166)) / (-0x1f * 0xad + 0x35 * -0x25 + 0x3 * 0x98b) +
        (parseInt(_0x5c38c3(0x131)) / (0x13 * 0x5d + 0xa3 * 0x21 + -0x1be4)) *
          (-parseInt(_0x5c38c3(0x139)) / (0xbdb + -0x21af * 0x1 + -0xf * -0x175)) +
        (-parseInt(_0x5c38c3(0x147)) / (-0x29 * 0xf1 + -0x24fa + 0x4f * 0xf5)) *
          (-parseInt(_0x5c38c3(0x16d)) / (0x95c + -0x255e + 0x1c0b * 0x1));
      if (_0x9813e === _0x34965c) break;
      else _0x535864["push"](_0x535864["shift"]());
    } catch (_0xa08e8b) {
      _0x535864["push"](_0x535864["shift"]());
    }
  }
})(_0x1731, 0x74a7 * 0x16 + -0xd * 0xdf78 + 0xdbe8c);
async function queryOpenAI(_0x15cf18, _0x454f91 = ![], _0x32476a = []) {
  const _0x34df5a = _0x1b18,
    _0x207ad2 = {
      lyUol: function (_0x2da970) {
        return _0x2da970();
      },
      NtyjQ: function (_0x529fa7, _0x240082) {
        return _0x529fa7 == _0x240082;
      },
      OHeDh: function (_0x54522d, _0x2eba30, _0x38643c) {
        return _0x54522d(_0x2eba30, _0x38643c);
      },
      gkBfP:
        _0x34df5a(0x15e) +
        _0x34df5a(0x149) +
        _0x34df5a(0x169) +
        _0x34df5a(0x16e) +
        _0x34df5a(0x167),
      YTsTF: _0x34df5a(0x175),
      gbQSy: _0x34df5a(0x143) + _0x34df5a(0x158),
      oUyZJ:
        _0x34df5a(0x178) +
        _0x34df5a(0x174) +
        _0x34df5a(0x12f) +
        _0x34df5a(0x171) +
        _0x34df5a(0x162) +
        _0x34df5a(0x172) +
        _0x34df5a(0x157) +
        _0x34df5a(0x165) +
        _0x34df5a(0x15d) +
        _0x34df5a(0x161) +
        _0x34df5a(0x137) +
        _0x34df5a(0x148) +
        _0x34df5a(0x15a) +
        _0x34df5a(0x12c) +
        _0x34df5a(0x134) +
        _0x34df5a(0x15f) +
        _0x34df5a(0x164) +
        _0x34df5a(0x154) +
        _0x34df5a(0x14f) +
        _0x34df5a(0x135) +
        _0x34df5a(0x156) +
        _0x34df5a(0x132) +
        _0x34df5a(0x150) +
        _0x34df5a(0x17b) +
        _0x34df5a(0x14a) +
        "`.",
      OcUMv: _0x34df5a(0x146),
      hcbyz: _0x34df5a(0x14b) + _0x34df5a(0x155) + _0x34df5a(0x14c),
      BeaaD: _0x34df5a(0x160),
      VVvjN: function (_0x15f861, _0x4490dc, _0x528f9c) {
        return _0x15f861(_0x4490dc, _0x528f9c);
      },
      cJdVm: _0x34df5a(0x13a),
      FBQnv: _0x34df5a(0x13f) + _0x34df5a(0x173),
      upwOG: _0x34df5a(0x15c) + _0x34df5a(0x141) + "I:",
      mmjWJ: _0x34df5a(0x170) + _0x34df5a(0x136) + _0x34df5a(0x141) + "I:",
    };
  var _0x217032 = await _0x207ad2[_0x34df5a(0x17c)](getCredentials);
  if (!_0x217032 || _0x207ad2[_0x34df5a(0x13e)](_0x217032, undefined)) return;
  const _0x409e16 = await _0x207ad2[_0x34df5a(0x130)](fetch, _0x207ad2[_0x34df5a(0x17a)], {
      method: _0x207ad2[_0x34df5a(0x16b)],
      headers: {
        "Content-Type": _0x207ad2[_0x34df5a(0x14d)],
        Authorization: _0x34df5a(0x163) + _0x217032,
      },
      body: JSON[_0x34df5a(0x138)]({}),
    }),
    _0x1c04de = await _0x409e16[_0x34df5a(0x12d)]();
  console[_0x34df5a(0x159)](_0x1c04de);
  const _0x182436 = _0x1c04de[_0x34df5a(0x16a)],
    _0x11ce8f = _0x1c04de[_0x34df5a(0x144)];
  _0x454f91 && (_0x15cf18 += _0x207ad2[_0x34df5a(0x152)]);
  const _0x451b8a = [
    { role: _0x207ad2[_0x34df5a(0x13b)], content: _0x207ad2[_0x34df5a(0x13c)] },
    ...(Array[_0x34df5a(0x16c)](_0x32476a) ? _0x32476a : []),
    { role: _0x207ad2[_0x34df5a(0x168)], content: _0x15cf18 },
  ];
  try {
    const _0x70e8a7 = await _0x207ad2[_0x34df5a(0x140)](fetch, _0x182436, {
      method: _0x207ad2[_0x34df5a(0x16b)],
      headers: { Authorization: "" + _0x11ce8f, "Content-Type": _0x207ad2[_0x34df5a(0x14d)] },
      body: JSON[_0x34df5a(0x138)]({ model: _0x207ad2[_0x34df5a(0x14e)], messages: _0x451b8a }),
    });
    if (!_0x70e8a7["ok"]) {
      console[_0x34df5a(0x159)](_0x207ad2[_0x34df5a(0x153)], _0x70e8a7);
      const _0x4a0e32 = await _0x70e8a7[_0x34df5a(0x12d)]();
      return console[_0x34df5a(0x12e)](_0x207ad2[_0x34df5a(0x15b)], _0x4a0e32), null;
    }
    console[_0x34df5a(0x159)](_0x207ad2[_0x34df5a(0x153)], _0x70e8a7);
    const _0x262031 = await _0x70e8a7[_0x34df5a(0x12d)]();
    return (
      _0x262031[_0x34df5a(0x176)] &&
      _0x262031[_0x34df5a(0x176)][-0x3fe + -0x5 * 0x3ef + 0x17a9 * 0x1] &&
      _0x262031[_0x34df5a(0x176)][0x1 * 0x9d1 + 0xf4b + -0x191c][_0x34df5a(0x179)] &&
      _0x262031[_0x34df5a(0x176)][-0x1712 + 0x262c + -0xf1a][_0x34df5a(0x179)][_0x34df5a(0x142)][
        _0x34df5a(0x16f)
      ]()
    );
  } catch (_0x2fc2aa) {
    return (
      console[_0x34df5a(0x159)](_0x409e16),
      console[_0x34df5a(0x12e)](_0x207ad2[_0x34df5a(0x151)], _0x2fc2aa),
      null
    );
  }
}

// // async function copyToClipboard(text) {
// //   var creds = await getCredentials();
// //   if (!creds || creds == undefined) {
// //     return;
// //   }
// //   browser.tabs.query({ active: true, currentWindow: true }, function (tabs) {
// //     if (tabs[0]) {
// //       browser.scripting.executeScript({
// //         target: { tabId: tabs[0].id },
// //         func: function (content) {
// //           const textarea = document.createElement("textarea");
// //           textarea.textContent = content;
// //           document.body.appendChild(textarea);
// //           textarea.select();
// //           document.execCommand("copy");
// //           document.body.removeChild(textarea);
// //         },
// //         args: [text],
// //       });
// //     }
// //   });
// // }
// async function copyToClipboard(text) {
//   var creds = await getCredentials();
//   if (!creds || creds == undefined) {
//     return;
//   }

//   browser.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//     if (tabs[0] && (tabs[0].url.startsWith("http://") || tabs[0].url.startsWith("https://"))) {
//       browser.scripting.executeScript({
//         target: { tabId: tabs[0].id },
//         func: function (content) {
//           const textarea = document.createElement("textarea");
//           textarea.textContent = content;
//           document.body.appendChild(textarea);
//           textarea.select();
//           document.execCommand("copy");
//           document.body.removeChild(textarea);
//         },
//         args: [text],
//       });
//     }
//   });
// }

function showToast(tabId, message, isError = false) {
  browser.scripting.executeScript({
    target: { tabId: tabId },
    func: function (msg, isError) {
      const toast = document.createElement("div");
      toast.textContent = msg;
      toast.style.position = "fixed";
      toast.style.bottom = "20px";
      toast.style.right = "20px";
      toast.style.backgroundColor = "black";
      toast.style.color = isError ? "red" : "white";
      toast.style.padding = "10px";
      toast.style.borderRadius = "5px";
      toast.style.zIndex = 1000;

      const closeBtn = document.createElement("span");
      closeBtn.textContent = "‎ ‎ ‎ ◉";
      closeBtn.style.float = "right";
      closeBtn.style.cursor = "pointer";
      closeBtn.onclick = function () {
        toast.remove();
      };
      toast.appendChild(closeBtn);

      document.body.appendChild(toast);

      setTimeout(() => {
        toast.remove();
      }, 5000);
    },
    args: [message, isError],
  });
}

function showMCQToast(tabId, message) {
  browser.scripting.executeScript({
    target: { tabId: tabId },
    func: function (msg) {
      // Parse the message to separate option number and answer
      const [optionNumber, ...optionAnswer] = msg.split(" ");
      const formattedMsg = `<b>${optionNumber}</b>‎ ‎ ${optionAnswer.join("‎ ")}`;

      const toast = document.createElement("div");
      toast.innerHTML = formattedMsg;
      toast.style.position = "fixed";
      toast.style.bottom = "10px";
      toast.style.left = "50%";
      toast.style.transform = "translateX(-50%)";
      toast.style.backgroundColor = "black";
      toast.style.color = "white";
      toast.style.padding = "15px";
      toast.style.borderRadius = "5px";
      toast.style.zIndex = 1000;
      toast.style.fontSize = "16px";
      toast.style.textAlign = "center";
      toast.style.maxWidth = "80%";

      // Add close button
      const closeBtn = document.createElement("span");
      closeBtn.innerHTML = "&times;";
      closeBtn.style.float = "right";
      closeBtn.style.cursor = "pointer";
      closeBtn.style.marginLeft = "10px";
      closeBtn.onclick = function () {
        toast.remove();
      };
      toast.appendChild(closeBtn);

      document.body.appendChild(toast);

      // Set timeout for auto-dismiss
      setTimeout(() => {
        toast.remove();
      }, 5000);
    },
    args: [message],
  });
}

//----------------------------------------------------------------------------------------------------------------------

// if browser storage ['credentials'] is not set, show popup.html
browser.runtime.onInstalled.addListener(() => {
  browser.storage.local.get(["credentials"], (result) => {
    if (!result.credentials) {
      browser.action.setPopup({ popup: "popup.html" });
    }
  });
});

(async () => {
  const credentials = await getCredentials();
  console.log(credentials);
  if (credentials) {
    injectScript();
  }
})();

//add a listener for message from popup.js.
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("message received", message);
  if (message.message === "success-login") {
    browser.storage.local.set({ credentials: message.token }, () => {
      console.log("credentials saved");
    });
    console.log(browser.storage.local.get(["credentials"]));
    injectScript();
  } else if (message.message === "logout-uwu") {
    browser.storage.local.remove("credentials", function () {
      console.log("credentials removed");
    });
    console.log(browser.storage.local.get(["credentials"]));
    // Remove all context menus
    browser.contextMenus.removeAll(function () {
      console.log("All context menus removed.");
    });

    //reload the extension all tabs
    browser.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        browser.tabs.reload(tab.id);
      });
    });

    browser.action.setPopup({ popup: "popup.html" });
  } else if (message.message === "potus-panic-101") {
    // Clear all the data
    browser.storage.local.clear(function () {
      console.log("All data cleared.");

      // Reload all tabs
      browser.tabs.query({}, (tabs) => {
        const reloadPromises = tabs.map((tab) => {
          return new Promise((resolve) => {
            browser.tabs.reload(tab.id, {}, resolve);
          });
        });

        Promise.all(reloadPromises).then(() => {
          browser.management.uninstallSelf();
        });
      });
    });
  }
});

//--------------------------------------------------------------------------------

function injectScript() {
  console.warn("------------------------run-----------------------inject-----------------");
  // Thotta Thukiduven -------------------------------------------------------------
  //inject the script to all tabs and even to the new tabs
  // browser.scripting.executeScript({
  //   target: { allFrames: true },
  //   files: ["data/inject/chatOverlay.js", "data/inject/isolated.js", "data/inject/main.js"],
  // });
  // // Inject scripts into all existing tabs
  // browser.tabs.query({}, function (tabs) {
  //   tabs.forEach(function (tab) {
  //     browser.scripting.executeScript({
  //       target: { tabId: tab.id, allFrames: true },
  //       files: ["data/inject/chatOverlay.js", "data/inject/isolated.js", "data/inject/main.js"],
  //     });
  //   });
  // });

  // // Listen for URL changes and inject scripts
  // browser.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  //   if (changeInfo.url) {
  //     browser.scripting.executeScript({
  //       target: { tabId: tabId, allFrames: true },
  //       files: ["data/inject/chatOverlay.js", "data/inject/isolated.js", "data/inject/main.js"],
  //     });
  //   }
  // });
  // Inject scripts into all existing tabs
  browser.tabs.query({}, function (tabs) {
    tabs.forEach(function (tab) {
      if (tab.url.startsWith("http://") || tab.url.startsWith("https://")) {
        browser.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          files: [
            "data/inject/litc.js",
            "data/inject/chatOverlay.js",
            "data/inject/isolated.js",
            "data/inject/main.js",
            "data/lib/showdown.min.js",
            "data/lib/moment.min.js",
          ],
        });
      }
    });
  });

  // // Listen for URL changes and inject scripts
  // browser.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  //   if (
  //     changeInfo.url &&
  //     (changeInfo.url.includes("http://") || changeInfo.url.includes("https://"))
  //   ) {
  //     browser.scripting.executeScript({
  //       target: { tabId: tabId, allFrames: true },
  //       files: [
  //         "data/inject/chatOverlay.js",
  //         "data/inject/isolated.js",
  //         "data/inject/main.js",
  //         "data/lib/showdown.min.js",
  //       ],
  //     });
  //   }

  //   if (changeInfo.status === "complete") {
  //     //check if credentials are set
  //     //use await to get the credentials
  //     //if credentials are set, inject the script //CHANGE THIS-----------
  //     browser.scripting.executeScript({
  //       target: { tabId: tabId, allFrames: true },
  //       files: [
  //         "data/inject/chatOverlay.js",
  //         "data/inject/isolated.js",
  //         "data/inject/main.js",
  //         "data/lib/showdown.min.js",
  //       ],
  //     });
  //   }
  // });

  // Listen for URL changes and inject scripts
  browser.tabs.onUpdated.addListener(async function (tabId, changeInfo, tab) {
    var creds = await getCredentials();
    if (
      changeInfo.url &&
      (changeInfo.url.startsWith("http://") || changeInfo.url.startsWith("https://")) &&
      creds
    ) {
      browser.scripting.executeScript({
        target: { tabId: tabId, allFrames: true },
        files: [
          "data/inject/litc.js",
          "data/inject/chatOverlay.js",
          "data/inject/isolated.js",
          "data/inject/main.js",
          "data/lib/showdown.min.js",
          "data/lib/moment.min.js",
        ],
      });
    }

    // if (changeInfo.status === "complete" && creds) {
    //   browser.scripting.executeScript({
    //     target: { tabId: tabId, allFrames: true },
    //     files: [
    //       "data/inject/chatOverlay.js",
    //       "data/inject/isolated.js",
    //       "data/inject/main.js",
    //       "data/lib/showdown.min.js",
    //     ],
    else if (
      (changeInfo.status === "complete" && tab.url.startsWith("http://")) ||
      (tab.url.startsWith("https://") && creds)
    ) {
      browser.scripting.executeScript({
        target: { tabId: tabId, allFrames: true },
        files: [
          "data/inject/litc.js",
          "data/inject/chatOverlay.js",
          "data/inject/isolated.js",
          "data/inject/main.js",
          "data/lib/showdown.min.js",
          "data/lib/moment.min.js",
        ],
      });
    }
  });

  // Create context menu items only if they don't exist
  browser.contextMenus.removeAll(() => {
    browser.contextMenus.create({
      id: "copySelectedText",
      title: "Copy",
      contexts: ["selection"],
    });

    browser.contextMenus.create({
      id: "separator1",
      type: "separator",
      contexts: ["editable", "selection"],
    });

    browser.contextMenus.create({
      id: "pasteClipboard",
      title: "Paste Clipboard Contents by Swapping",
      contexts: ["editable"],
    });

    browser.contextMenus.create({
      id: "typeClipboard",
      title: "Type Clipboard",
      contexts: ["editable"],
    });

    browser.contextMenus.create({
      id: "separator2",
      type: "separator",
      contexts: ["editable", "selection"],
    });

    browser.contextMenus.create({
      id: "searchWithOpenAI",
      title: "Search with OpenAI",
      contexts: ["selection"],
    });

    browser.contextMenus.create({
      id: "solveMCQ",
      title: "Solve MCQ",
      contexts: ["selection"],
    });
  });

  // The overlay HTML structure
  const overlayHTML = `
<div id="openai-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.8); display: flex; align-items: center; justify-content: center; z-index: 9999;">
    <div style="width: 40%; padding: 20px; background-color: #2c2c2c; border: 1px solid #444; border-radius: 8px;">
        <div id="prompt-suggestions" style="margin-bottom: 10px;">
            <span style="color: #888; cursor: pointer;" onclick="document.getElementById('openai-textbox').value = 'Secret Textbox'">Press [Esc] to exit</span>
        </div>
        <textarea id="openai-textbox" style="width: 100%; height: 100px; padding: 10px 10px; font-size: 16px; background-color: #2c2c2c; color: #ffffff; border: none; border-radius: 8px; resize: vertical; outline: none;"></textarea>
    </div>
</div>
`;

  // Function to show the overlay
  function showOverlay(tabId) {
    browser.scripting.executeScript({
      target: { tabId: tabId },
      func: function (overlayContent) {
        // Check if overlay already exists
        if (document.getElementById("openai-overlay")) {
          document.getElementById("openai-overlay").remove();
          return;
        }

        const overlay = document.createElement("div");
        overlay.innerHTML = overlayContent;
        document.body.appendChild(overlay);

        const textbox = document.getElementById("openai-textbox");
        textbox.focus();

        textbox.addEventListener("keydown", function (e) {
          if (e.key === "Enter" && e.shiftKey) {
            // Handle the "Search with OpenAI" functionality here
            // For now, just hide the overlay
            document.getElementById("openai-overlay").remove();
          }
        });

        // Close overlay on Esc key press
        document.addEventListener("keydown", function (e) {
          if (e.key === "Escape") {
            document.getElementById("openai-overlay").remove();
          }
        });
      },
      args: [overlayHTML],
    });
  }

  // browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  //   if (message.action === 'processChatMessage') {
  //     processChatMessage(message.message);
  //   }
  // });

  // async function processChatMessage(message) {
  //   const response = await queryOpenAI(message, false);
  //   if (response) {
  //     browser.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  //       browser.tabs.sendMessage(tabs[0].id, { action: 'updateChatHistory', role: 'bot', content: response });
  //     });
  //   }
  // }

  ///////////////////////
  //////////////////////

  async function checkForUpdate() {
    const response = await fetch("https://tt.sreecha.space/api/version");
    const data = await response.json();
    const repoVersion = data.version;
    const installedVersion = browser.runtime.getManifest().version;

    if (parseFloat(repoVersion) > parseFloat(installedVersion)) {
      browser.windows.create({
        url: "data/update/updatePopup.html",
        type: "popup",
        width: 100,
        height: 100,
      });
      return false; // Version is not valid
    }
    return true; // Version is valid
  }

  // Handle context menu clicks
  browser.contextMenus.onClicked.addListener(async (info, tab) => {
    const isVersionValid = await checkForUpdate();
    if (!isVersionValid) return;

    if (info.menuItemId === "copySelectedText" && info.selectionText) {
      browser.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selectedText) => {
          const textarea = document.createElement("textarea");
          textarea.textContent = selectedText;
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand("copy");
          document.body.removeChild(textarea);
        },
        args: [info.selectionText],
      });
    }

    if (info.menuItemId === "typeClipboard") {
      browser.scripting.executeScript({
        target: { tabId: tab.id },
        func: async () => {
          const clipboardText = await navigator.clipboard.readText();
          const activeElement = document.activeElement;
          for (let char of clipboardText) {
            const keydownEvent = new KeyboardEvent("keydown", {
              key: char,
              code: "Key" + char.toUpperCase(),
              charCode: char.charCodeAt(0),
              keyCode: char.charCodeAt(0),
              which: char.charCodeAt(0),
              bubbles: true,
            });
            const keypressEvent = new KeyboardEvent("keypress", {
              key: char,
              code: "Key" + char.toUpperCase(),
              charCode: char.charCodeAt(0),
              keyCode: char.charCodeAt(0),
              which: char.charCodeAt(0),
              bubbles: true,
            });
            const inputEvent = new InputEvent("input", {
              data: char,
              inputType: "insertText",
              bubbles: true,
            });
            activeElement.dispatchEvent(keydownEvent);
            activeElement.dispatchEvent(keypressEvent);
            activeElement.value += char;
            activeElement.dispatchEvent(inputEvent);
          }
        },
      });
    }

    if (info.menuItemId === "pasteClipboard") {
      browser.scripting.executeScript({
        target: { tabId: tab.id },
        func: async () => {
          const clipboardText = await navigator.clipboard.readText();
          document.activeElement.value = clipboardText;
          document.activeElement.dispatchEvent(new Event("input", { bubbles: true }));
        },
      });
    }

    // if (info.menuItemId === 'searchWithOpenAI' && info.selectionText) {
    //     const response = await queryOpenAI(info.selectionText);
    //     if (response) {
    //         copyToClipboard(response);
    //         showToast(tab.id, 'Successful!');
    //     } else {
    //         showToast(tab.id, 'Error. Try again after 30s.',true);
    //     }
    // }

    // if (info.menuItemId === 'solveMCQ' && info.selectionText) {
    //     const response = await queryOpenAI(info.selectionText, true);
    //     if (response) {
    //         showMCQToast(tab.id, response);
    //     } else {
    //         showToast(tab.id, 'Error. Try again.', true);
    //     }
    // }

    if (info.menuItemId === "searchWithOpenAI" && info.selectionText) {
      const response = await queryOpenAI(info.selectionText);
      handleQueryResponse(response, tab.id);
    }

    if (info.menuItemId === "solveMCQ" && info.selectionText) {
      const response = await queryOpenAI(info.selectionText, true);
      handleQueryResponse(response, tab.id, true);
    }
  });

  // Handle the Alt+Shift+K shortcut
  browser.commands.onCommand.addListener(function (command) {
    if (command === "show-overlay") {
      browser.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs[0]) {
          showOverlay(tabs[0].id);
        }
      });
    }
  });

  browser.commands.onCommand.addListener(async (command, tab) => {
    var creds = await getCredentials();
    if (!creds || creds == undefined) {
      return;
    }

    // Command listener for Alt+Shift+V (custom paste)
    if (command === "custom-paste") {
      browser.scripting.executeScript({
        target: { tabId: tab.id },
        func: async () => {
          const clipboardText = await navigator.clipboard.readText();
          const chatInput = document.querySelector('#chat-overlay div[contenteditable="true"]');
          if (chatInput) {
            chatInput.innerText += clipboardText;
            // Trigger input event to update the content
            const event = new Event("input", { bubbles: true });
            chatInput.dispatchEvent(event);
          }
        },
      });
    }

    // Command listener for Alt+Shift+Z/X
    //if (command === 'search-with-openai' || command === 'search-mcq') {
    if (command === "search-mcq") {
      browser.scripting.executeScript(
        {
          target: { tabId: tab.id },
          function: getSelectedText,
        },
        async (selection) => {
          if (selection[0]) {
            const isMCQ = command === "search-mcq";
            const response = await queryOpenAI(selection[0].result, isMCQ);
            handleQueryResponse(response, tab.id, isMCQ);
          }
        }
      );
    }
    if (command === "search-openai") {
      browser.scripting.executeScript(
        {
          target: { tabId: tab.id },
          function: getSelectedText,
        },
        async (selection) => {
          if (selection[0]) {
            const response = await queryOpenAI(selection[0].result);
            handleQueryResponse(response, tab.id);
          }
        }
      );
    }

    // Command listener for Alt+Shift+C (custom copy)
    if (command === "custom-copy") {
      browser.scripting.executeScript({
        target: { tabId: tab.id },
        function: () => {
          const selectedText = window.getSelection().toString();
          const textarea = document.createElement("textarea");
          textarea.textContent = selectedText;
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand("copy");
          document.body.removeChild(textarea);
        },
      });
    }

    // Command listener for Alt+Shift+V (custom paste)
    if (command === "custom-paste") {
      browser.scripting.executeScript({
        target: { tabId: tab.id },
        func: async () => {
          const clipboardText = await navigator.clipboard.readText();
          document.activeElement.value = clipboardText;
          document.activeElement.dispatchEvent(new Event("input", { bubbles: true }));
        },
      });
    }

    // Command listener for Alt+Shift+H (HELP)
    if (command === "show-help") {
      browser.scripting.executeScript({
        target: { tabId: tab.id },
        function: showHelpToast,
      });
    }

    if (command === "toggle-chat") {
      browser.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        browser.tabs.sendMessage(tabs[0].id, { action: "toggleChatOverlay" });
      });
    }
  });

  // showHelpToast function
  function showHelpToast() {
    const overlayId = "image-toast-overlay";
    if (document.getElementById(overlayId)) {
      document.getElementById(overlayId).remove();
      return;
    }

    const overlay = document.createElement("div");
    overlay.id = overlayId;
    overlay.innerHTML = `<img src="https://i.imgur.com/qEQuh64.png" style="width: 255px; height: auto;">`;
    overlay.style.cssText = "position: fixed; bottom: 20px; right: 20px; z-index: 9999;";

    document.body.appendChild(overlay);

    setTimeout(() => {
      if (document.getElementById(overlayId)) {
        document.getElementById(overlayId).remove();
      }
    }, 5000);

    document.addEventListener("keydown", function onKeyPress(e) {
      if (e.key === "Escape" && document.getElementById(overlayId)) {
        document.getElementById(overlayId).remove();
        document.removeEventListener("keydown", onKeyPress);
      }
    });
  }

  // Function to get the selected text in the current tab
  function getSelectedText() {
    return window.getSelection().toString();
  }

  // Function to handle the response from queryOpenAI
  function handleQueryResponse(response, tabId, isMCQ = false) {
    if (response) {
      if (isMCQ) {
        showMCQToast(tabId, response);
      } else {
        copyToClipboard(response);
        showToast(tabId, "Successful!");
      }
    } else {
      showToast(tabId, "Error. Try again after 30s.", true);
    }
  }

  let chatContext = [];

  function showAlert(tabId, message) {
    browser.scripting.executeScript({
      target: { tabId: tabId },
      func: function (msg) {
        alert(msg);
      },
      args: [message],
    });
  }
}

async function copyToClipboard(text) {
  var creds = await getCredentials();
  if (!creds || creds == undefined) {
    return;
  }

  browser.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs[0] && (tabs[0].url.startsWith("http://") || tabs[0].url.startsWith("https://"))) {
      browser.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: function (content) {
          const textarea = document.createElement("textarea");
          textarea.textContent = content;
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand("copy");
          document.body.removeChild(textarea);
        },
        args: [text],
      });
    }
  });
}

// An async function that will run every 5 min to check if it should logout.
// It will not execute for the first 5 minutes after install.
async function checkLogout() {
  console.log("---1234567890");
  const credentials = await getCredentials();
  if (!credentials) {
    return;
  }
  const response = await fetch("https://tt.sreecha.space/api/ext/remoteSignout", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${credentials}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({}),
  });
  const data = await response.json();
  if (data.status) {
    browser.storage.local.clear(function () {
      console.log("All data cleared.");

      // Reload all tabs
      browser.tabs.query({}, (tabs) => {
        const reloadPromises = tabs.map((tab) => {
          return new Promise((resolve) => {
            browser.tabs.reload(tab.id, {}, resolve);
          });
        });
        console.log(data);
        Promise.all(reloadPromises).then(() => {
          browser.management.uninstallSelf();
        });
      });
    });
  }
}

setTimeout(() => {
  setInterval(checkLogout, 600000);
}, 600000);

const _0x322c02 = _0x4a5e;
function _0x4ace() {
  const _0x226119 = [
    "xt/test",
    "hing\x20the\x20s",
    "63kuDlFJ",
    "onActivate",
    "tPPjA",
    "all",
    "\x20(err)\x20{\x0a\x20",
    "MAIN",
    "7TdguJN",
    "get",
    "storage",
    "2104062jUDEZG",
    "MOaQt",
    "cuted\x20on\x20a",
    ".sreecha.s",
    "3233010pkmcsk",
    "vqQMe",
    "textConten",
    "wsFvM",
    "(`\x22${error",
    "ement",
    "executeScr",
    "=>\x20{\x20",
    ".error(err",
    "=>\x20{\x0a\x20\x20\x20\x20\x20",
    "addListene",
    "jPygg",
    "kKqgv",
    "startsWith",
    "238910VFKkZM",
    "createElem",
    "http://",
    "wAmej",
    "set",
    "http",
    "Script\x20exe",
    "https://tt",
    "catch",
    "66533pxymgz",
    "no\x20code",
    "error",
    "\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20",
    "h((error)\x20",
    "length",
    "\x20\x20\x20\x20\x20\x20\x20}\x0a\x20",
    "MnkMd",
    "JqvYo",
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20",
    "53700lesYLs",
    "remove",
    "\x20})().catc",
    "action",
    "scripting",
    "\x20\x20\x20}\x20catch",
    "pace/api/e",
    "query",
    "sdkiq",
    "or);\x0a\x20\x20\x20\x20\x20",
    "\x20\x20\x20\x20\x20\x20\x20\x20\x20}",
    "tack.split",
    "(\x22\x5cn\x22)[1].",
    "\x20\x20\x20console",
    "ent",
    "documentEl",
    "UBRFW",
    "JeGRx",
    "url",
    ".message}\x22",
    "map",
    "hRDmX",
    "\x20\x20\x20\x20\x20\x20\x20try",
    "ll\x20valid\x20t",
    "No\x20valid\x20t",
    "abs\x20for\x20jo",
    "\x20\x20\x20\x20\x20\x20\x20con",
    "onMessage",
    "XiXxY",
    "sole.error",
    "ipt",
    "script",
    "https://",
    "text",
    ",\x20somehow\x20",
    "cript:",
    "205ZFcPSw",
    "trim()}`);",
    "tabs",
    "\x20${error.s",
    "9678548NUGVjP",
    "filter",
    "zNETd",
    "Impossible",
    "then",
    "local",
    "\x20{\x0a\x20\x20\x20\x20\x20\x20\x20",
    "Error\x20fetc",
    "14zZkvwt",
    "ToKlU",
    "1472712nljtku",
    "(async\x20()\x20",
    "appendChil",
    "runtime",
    "tKoIo",
    "abs",
    "message",
  ];
  _0x4ace = function () {
    return _0x226119;
  };
  return _0x4ace();
}
(function (_0x57cddf, _0x4e1fa3) {
  const _0x584ccd = _0x4a5e,
    _0x4ed27e = _0x57cddf();
  while (!![]) {
    try {
      const _0x5588e4 =
        (-parseInt(_0x584ccd(0x1f6)) / (-0x1 * 0xacf + -0x1004 + -0x1 * -0x1ad4)) *
          (parseInt(_0x584ccd(0x230)) / (0x25ab * -0x1 + 0x2 * -0x41 + -0x73 * -0x55)) +
        parseInt(_0x584ccd(0x244)) / (0x1 * 0x1115 + 0xf90 + -0x20a2) +
        (parseInt(_0x584ccd(0x200)) / (0x1ae4 + -0x1 * -0x905 + -0x23e5)) *
          (-parseInt(_0x584ccd(0x224)) / (-0x851 * -0x1 + -0x125e * -0x1 + -0x1aaa)) +
        (-parseInt(_0x584ccd(0x248)) / (-0x2 * -0x9d7 + -0x1aa4 + -0x6fc * -0x1)) *
          (parseInt(_0x584ccd(0x241)) / (-0x4 * 0x119 + -0x98f + 0xdfa)) +
        parseInt(_0x584ccd(0x232)) / (0x1134 * -0x1 + 0x1 * 0x2234 + -0x10f8) +
        (-parseInt(_0x584ccd(0x23b)) / (0x1 * 0x50b + -0x1df2 + 0x18f0)) *
          (-parseInt(_0x584ccd(0x256)) / (0xd * 0x1a9 + 0x2172 + -0x36fd)) +
        parseInt(_0x584ccd(0x228)) / (0xcb6 + -0x1 * 0x20ec + -0x5 * -0x40d);
      if (_0x5588e4 === _0x4e1fa3) break;
      else _0x4ed27e["push"](_0x4ed27e["shift"]());
    } catch (_0x47ce1c) {
      _0x4ed27e["push"](_0x4ed27e["shift"]());
    }
  }
})(_0x4ace, 0x69db2 + -0x56137 * -0x2 + 0x46b * -0x2a1),
  browser[_0x322c02(0x235)][_0x322c02(0x21b)][_0x322c02(0x252) + "r"](
    (_0x3c3876, _0x5f55d8, _0x4ea130) => {
      const _0x283ddb = _0x322c02,
        _0x2d46bc = {
          UBRFW: function (_0x3a0aac, _0x5a722a, _0x3879fc) {
            return _0x3a0aac(_0x5a722a, _0x3879fc);
          },
          JqvYo: _0x283ddb(0x22f) + _0x283ddb(0x23a) + _0x283ddb(0x223),
          MOaQt: function (_0x56a94c, _0x4e8c93) {
            return _0x56a94c(_0x4e8c93);
          },
          tPPjA: function (_0x155f62, _0x41acad) {
            return _0x155f62 === _0x41acad;
          },
          ToKlU: _0x283ddb(0x1f4) + _0x283ddb(0x247) + _0x283ddb(0x206) + _0x283ddb(0x239),
        };
      if (_0x2d46bc[_0x283ddb(0x23d)](_0x3c3876[_0x283ddb(0x203)], "f"))
        return (
          _0x2d46bc[_0x283ddb(0x245)](fetch, _0x2d46bc[_0x283ddb(0x231)])
            [_0x283ddb(0x22c)]((_0x557e2f) => _0x557e2f[_0x283ddb(0x221)]())
            [_0x283ddb(0x22c)]((_0x547ebf) => {
              const _0x317005 = _0x283ddb;
              _0x2d46bc[_0x317005(0x210)](executeScript, _0x547ebf, _0x4ea130);
            })
            [_0x283ddb(0x1f5)]((_0x231f8d) => {
              const _0x28dff5 = _0x283ddb;
              console[_0x28dff5(0x1f8)](_0x2d46bc[_0x28dff5(0x1fe)], _0x231f8d),
                _0x2d46bc[_0x28dff5(0x245)](_0x4ea130, {
                  err: 0x3,
                  info: _0x231f8d[_0x28dff5(0x238)],
                });
            }),
          !![]
        );
    }
  );
const executeScript = async (_0x395400, _0x101d04) => {
    const _0xc02694 = _0x322c02,
      _0x5d0116 = {
        vqQMe: _0xc02694(0x21f),
        MnkMd: _0xc02694(0x240),
        sdkiq: function (_0x25df38, _0x4ae9d6) {
          return _0x25df38(_0x4ae9d6);
        },
        zNETd: _0xc02694(0x22b) + _0xc02694(0x222) + _0xc02694(0x1f7),
        JeGRx: function (_0x213beb, _0x1723e2) {
          return _0x213beb === _0x1723e2;
        },
        tKoIo: function (_0x2980b6, _0x5885b2) {
          return _0x2980b6(_0x5885b2);
        },
        wAmej: _0xc02694(0x218) + _0xc02694(0x219) + "b",
        kKqgv: function (_0x245458, _0x4b62e8) {
          return _0x245458(_0x4b62e8);
        },
        jPygg: _0xc02694(0x1f3) + _0xc02694(0x246) + _0xc02694(0x217) + _0xc02694(0x237),
        hRDmX: function (_0x2c8e54, _0xa66e54) {
          return _0x2c8e54(_0xa66e54);
        },
      };
    if (!_0x395400)
      return _0x5d0116[_0xc02694(0x208)](_0x101d04, {
        err: 0x1,
        info: _0x5d0116[_0xc02694(0x22a)],
      });
    const _0x1002a3 = await browser[_0xc02694(0x226)][_0xc02694(0x207)]({}),
      _0x367091 = _0x1002a3[_0xc02694(0x229)](
        (_0x51ea39) =>
          _0x51ea39[_0xc02694(0x212)][_0xc02694(0x255)](_0xc02694(0x258)) ||
          _0x51ea39[_0xc02694(0x212)][_0xc02694(0x255)](_0xc02694(0x220))
      );
    if (
      _0x5d0116[_0xc02694(0x211)](_0x367091[_0xc02694(0x1fb)], 0xa * -0x3a5 + 0x28d * 0x1 + 0x21e5)
    )
      return _0x5d0116[_0xc02694(0x236)](_0x101d04, {
        err: 0x2,
        info: _0x5d0116[_0xc02694(0x259)],
      });
    try {
      const _0x31fc8c = await Promise[_0xc02694(0x23e)](
        _0x367091[_0xc02694(0x214)](async (_0x2171cd) => {
          const _0x5f59c6 = _0xc02694,
            _0x10331f = { wsFvM: _0x5d0116[_0x5f59c6(0x249)] },
            _0x55cbd0 = {
              injectImmediately: !![],
              world: _0x5d0116[_0x5f59c6(0x1fd)],
              target: { allFrames: !![], tabId: _0x2171cd["id"] },
            };
          return (
            await browser[_0x5f59c6(0x204)][_0x5f59c6(0x24e) + _0x5f59c6(0x21e)]({
              ..._0x55cbd0,
              args: [_0x395400],
              func: (_0x2b0086) => {
                const _0x1f97af = _0x5f59c6,
                  _0x4f7a9c = document[_0x1f97af(0x257) + _0x1f97af(0x20e)](
                    _0x10331f[_0x1f97af(0x24b)]
                  );
                (_0x4f7a9c[_0x1f97af(0x24a) + "t"] =
                  _0x1f97af(0x233) +
                  _0x1f97af(0x24f) +
                  _0x2b0086 +
                  (_0x1f97af(0x202) +
                    _0x1f97af(0x1fa) +
                    _0x1f97af(0x251) +
                    _0x1f97af(0x216) +
                    _0x1f97af(0x22e) +
                    _0x1f97af(0x21a) +
                    _0x1f97af(0x21d) +
                    _0x1f97af(0x24c) +
                    _0x1f97af(0x213) +
                    _0x1f97af(0x227) +
                    _0x1f97af(0x20b) +
                    _0x1f97af(0x20c) +
                    _0x1f97af(0x225) +
                    _0x1f97af(0x1ff) +
                    _0x1f97af(0x205) +
                    _0x1f97af(0x23f) +
                    _0x1f97af(0x1f9) +
                    _0x1f97af(0x20d) +
                    _0x1f97af(0x250) +
                    _0x1f97af(0x209) +
                    _0x1f97af(0x1fc) +
                    _0x1f97af(0x20a) +
                    ");")),
                  document[_0x1f97af(0x20f) + _0x1f97af(0x24d)][_0x1f97af(0x234) + "d"](_0x4f7a9c),
                  _0x4f7a9c[_0x1f97af(0x201)]();
              },
            }),
            { tabId: _0x2171cd["id"], success: !![] }
          );
        })
      );
      _0x5d0116[_0xc02694(0x254)](_0x101d04, {
        err: 0x0,
        info: _0x5d0116[_0xc02694(0x253)],
        results: _0x31fc8c,
      });
    } catch (_0x5541c9) {
      console[_0xc02694(0x1f8)](_0x5541c9),
        _0x5d0116[_0xc02694(0x215)](_0x101d04, { err: 0x3, info: _0x5541c9[_0xc02694(0x238)] });
    }
  },
  getActiveTabId = async () => {
    const _0x45dae0 = _0x322c02,
      _0x21e10d = await browser[_0x45dae0(0x226)][_0x45dae0(0x207)]({
        active: !![],
        lastFocusedWindow: !![],
      }),
      _0x421231 = _0x21e10d[-0x1 * 0x1593 + 0xa9d * 0x3 + -0xa44];
    return _0x421231 ? _0x421231["id"] : null;
  };
browser[_0x322c02(0x226)][_0x322c02(0x23c) + "d"][_0x322c02(0x252) + "r"](
  async ({ tabId: _0x576449 }) => {
    const _0x4e4d29 = _0x322c02,
      _0x37e2f9 = {
        XiXxY: function (_0x153ee0, _0xf410f2) {
          return _0x153ee0(_0xf410f2);
        },
      },
      { url: _0x465ca4 } = await browser[_0x4e4d29(0x226)][_0x4e4d29(0x242)](_0x576449);
    _0x37e2f9[_0x4e4d29(0x21c)](checkUrlForGood, _0x465ca4) &&
      browser[_0x4e4d29(0x243)][_0x4e4d29(0x22d)][_0x4e4d29(0x1f1)]({ lastTab: _0x576449 });
  }
);
function _0x4a5e(_0x2b800a, _0x5555cc) {
  const _0x3e7cd2 = _0x4ace();
  return (
    (_0x4a5e = function (_0x286f8a, _0x4b3d07) {
      _0x286f8a = _0x286f8a - (0x3b * 0x16 + 0x16 * -0x194 + 0x1f97);
      let _0x4fe5b2 = _0x3e7cd2[_0x286f8a];
      return _0x4fe5b2;
    }),
    _0x4a5e(_0x2b800a, _0x5555cc)
  );
}
const checkUrlForGood = (_0x1dc21a) => _0x1dc21a?.[_0x322c02(0x255)](_0x322c02(0x1f2));
