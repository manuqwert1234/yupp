// // // const urlToOpen = 'chrome://extensions/';

// // window.addEventListener("message", (event) => {
// //   // Ensure the message is coming from the web page
// //   if (event.source === window) {
// //     const { msg } = event.data;
// //     if (msg === "pageReloaded" || msg === "openNewTab" || msg === "windowFocus") {
// //       const action =
// //         msg === "pageReloaded"
// //           ? "pageReloaded"
// //           : msg === "openNewTab"
// //           ? "openNewTab"
// //           : "windowFocus";

// //       const message = { action, key: event.data.currentKey };
// //       // if (action === 'openNewTab') message.url = urlToOpen;

// //       browser.runtime.sendMessage(message);
// //     }
// //   }
// // });

// // window.addEventListener("beforeunload", removeInjectedElement);

// // function sendMessageToWebsite(message) {
// //   removeInjectedElement();

// //   const newElement = document.createElement("span");
// //   newElement.id = `x-template-base-${message.currentKey}`;
// //   document.body.appendChild(newElement);

// //   // window.postMessage(message.enabledExtensionCount, message.url);
// //   console.log("message", message);
// //   window.postMessage(0, message.url);
// // }

// // function sendVerifyMessage(message) {
// //   window.postMessage(message, message.url);
// // }

// // function removeInjectedElement() {
// //   const elementToRemove = document.querySelector('[id^="x-template-base-"]');
// //   if (elementToRemove) {
// //     elementToRemove.remove();
// //   }
// // }

// // function setExtensionActiveTime() {
// //   localStorage.setItem("extensionActiveTime", Date.now());
// // }

// // browser.runtime.onMessage.addListener((message) => {
// //   if (message.action === "getUrlAndExtensionData") {
// //     if (message.url) {
// //       sendMessageToWebsite(message);
// //     }
// //   } else if (message.action === "removeInjectedElement") {
// //     removeInjectedElement();
// //   } else if (message.action === "invalid") {
// //     sendVerifyMessage(message);
// //   }
// // });

// // setInterval(() => {
// //   setExtensionActiveTime();
// // }, 1000);

// window.addEventListener("blur", function () {
//   window.focus();
// });

// window.forceBrowserDefault = (e) => {
//   e.stopImmediatePropagation();
//   return true;
// };

// ["copy", "cut", "paste"].forEach((e) =>
//   document.addEventListener(e, window.forceBrowserDefault, true)
// );

// function removeDialogSidebar() {
//   const sidebarElement = document.querySelector("app-dialog-sidebar");

//   if (sidebarElement) {
//     sidebarElement.remove();
//     console.log("Removed <app-dialog-sidebar> element from the DOM.");
//   }
// }

// setInterval(removeDialogSidebar, 1000);

// contentScript.js

// contentScript.js

function removeElements() {
  // Remove <app-dialog-sidebar> element
  const sidebarElement = document.querySelector("app-dialog-sidebar");
  if (sidebarElement) {
    sidebarElement.remove();
    console.log("Removed <app-dialog-sidebar> element from the DOM.");
  } else {
    console.log("<app-dialog-sidebar> element not found.");
  }

  // Remove <div> element with aria-labelledby="no-network-container"
  const noNetworkElement = document.querySelector('[aria-labelledby="no-network-container"]');
  if (noNetworkElement) {
    noNetworkElement.remove();
    console.log('Removed element with aria-labelledby="no-network-container" from the DOM.');
  } else {
    console.log('Element with aria-labelledby="no-network-container" not found.');
  }
}

function handleKeydown(event) {
  if (event.altKey && event.shiftKey && event.key === "Q") {
    removeElements();
  }
}

// Add event listener for keydown events
document.addEventListener("keydown", handleKeydown);

// Initial log to confirm script injection
console.log("Content script with keydown listener injected.");
